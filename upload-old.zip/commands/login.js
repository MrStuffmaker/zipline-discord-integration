import { SlashCommandBuilder } from 'discord.js';
import { validateToken, getUserData } from '../utils/auth.js';
import { writeUserData } from '../database/dbHandler.js';
import { join } from 'path';
import { promises as fs } from 'fs';

const USERS_DATA_PATH = join(__dirname, '../../data/users');

export default {
    data: new SlashCommandBuilder()
        .setName('login')
        .setDescription('Log in with your Zipline user token')
        .addStringOption(option =>
            option.setName('token')
                .setDescription('Your Zipline user token')
                .setRequired(true)),
    async execute(interaction) {
        const token = interaction.options.getString('token');

        // Validate the token
        const isValid = validateToken(token);
        if (!isValid) {
            return interaction.reply({ content: '❌ Invalid token. Please check your Zipline user token and try again.', ephemeral: true });
        }

        // Get user data from Zipline
        const userData = await getUserData(token);
        if (!userData) {
            return interaction.reply({ content: '❌ Unable to retrieve user data. Please try again later.', ephemeral: true });
        }

        // Store user data in the /data/users folder
        const userFilePath = join(USERS_DATA_PATH, `${interaction.user.id}.json`);
        await fs.writeFile(userFilePath, JSON.stringify({ token, ...userData }, null, 2));

        return interaction.reply({ content: '✅ Successfully logged in! Your user data has been stored.', ephemeral: true });
    },
};