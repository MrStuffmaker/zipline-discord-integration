import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { getUserHistory } from '../database/dbHandler.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export default {
    data: new SlashCommandBuilder()
        .setName('history')
        .setDescription('View your upload history'),

    async execute(interaction) {
        await interaction.deferReply();

        const userId = interaction.user.id;
        const history = getUserHistory(userId);

        if (history.length === 0) {
            return await interaction.editReply({
                content: '📋 You have no uploads yet!',
            });
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📋 Your Upload History')
            .setDescription(`Total uploads: ${history.length}`)
            .setTimestamp();

        history.slice(-10).reverse().forEach((upload, index) => {
            const date = new Date(upload.timestamp).toLocaleString();
            embed.addFields({
                name: `#${history.length - index} - ${upload.fileName}`,
                value: `[View](${upload.url})\n**Uploaded:** ${date}`,
                inline: false,
            });
        });

        await interaction.editReply({ embeds: [embed] });
    },
};