// commands/settings.js

import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { deleteHistory } from '../database/dbHandler.js'; 

export default {
    data: new SlashCommandBuilder()
        .setName('settings')
        .setDescription('Manage your Zipline bot data and settings.')
        .setDMPermission(true)
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete_data')
                .setDescription('WARNING: Permanently deletes ALL your recorded upload history.')),

    async execute(interaction) {
        if (interaction.options.getSubcommand() === 'delete_data') {
            const userId = interaction.user.id;
            
            const confirmId = `delete_confirm_${userId}`;
            const cancelId = `delete_cancel_${userId}`;

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(confirmId)
                    .setLabel('Yes, Delete My Data')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId(cancelId)
                    .setLabel('No, Keep My Data')
                    .setStyle(ButtonStyle.Secondary),
            );

            await interaction.reply({
                content: '⚠️ **Are you sure?** This action will permanently delete all your upload history. This cannot be undone.',
                components: [row],
                ephemeral: true
            });
            
            const filter = i => (i.customId === confirmId || i.customId === cancelId) && i.user.id === userId;
            
            try {
                const confirmation = await interaction.channel.awaitMessageComponent({ filter, time: 30000 });
                
                if (confirmation.customId === confirmId) {
                    await confirmation.deferUpdate();
                    
                    const success = await deleteHistory(userId);
                    
                    if (success) {
                        await confirmation.editReply({ 
                            content: '✅ All your data has been **permanently deleted**. You can now start fresh.', 
                            components: [] 
                        });
                    } else {
                        await confirmation.editReply({ 
                            content: '❌ An error occurred during data deletion. Check the console.', 
                            components: [] 
                        });
                    }
                } else if (confirmation.customId === cancelId) {
                    await confirmation.update({ content: '👌 Data deletion cancelled. Your history is safe.', components: [] });
                }
                
            } catch (e) {
                await interaction.editReply({ content: 'Action timed out. Data deletion cancelled.', components: [] });
            }
        }
    }
};