import { SlashCommandBuilder } from 'discord.js';
import { uploadFileToZipline } from '../utils/zipline.js';
import { getUserData } from '../database/dbHandler.js';

export default {
    data: new SlashCommandBuilder()
        .setName('upload')
        .setDescription('Upload a file to Zipline.')
        .addAttachmentOption(option => 
            option.setName('file')
                .setDescription('The file to upload')
                .setRequired(true)),
    async execute(interaction) {
        const userId = interaction.user.id;
        const userData = await getUserData(userId);

        if (!userData || !userData.ziplineToken) {
            return interaction.reply({ content: '❌ You need to log in with your Zipline token first using the /login command.', ephemeral: true });
        }

        const file = interaction.options.getAttachment('file');

        try {
            const uploadResponse = await uploadFileToZipline(file.url, userData.ziplineToken);
            interaction.reply({ content: `✅ File uploaded successfully! URL: ${uploadResponse.url}`, ephemeral: true });
        } catch (error) {
            console.error('Error uploading file:', error);
            interaction.reply({ content: '❌ An error occurred while uploading the file.', ephemeral: true });
        }
    },
};