import { Client, GatewayIntentBits, Collection, ActivityType } from 'discord.js';
import * as dotenv from 'dotenv';
import { readdirSync } from 'fs';
import { fileURLToPath, pathToFileURL } from 'url'; 
import { dirname, join } from 'path';

dotenv.config();

const CUSTOM_STATUS = process.env.BOT_STATUS || 'Uploading to Zipline...';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.DirectMessages, 
    ] 
});

client.commands = new Collection();
const commandsPath = join(__dirname, 'commands');
const commandFiles = readdirSync(commandsPath).filter(file => file.endsWith('.js'));

console.log(`Loading ${commandFiles.length} command files...`);

for (const file of commandFiles) {
    const filePath = join(commandsPath, file);
    const fileUrl = pathToFileURL(filePath).href; 

    import(fileUrl)
        .then(module => {
            const command = module.default;
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
            } else {
                console.warn(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
            }
        })
        .catch(error => {
            console.error(`Failed to load command ${file}:`, error);
        });
}

client.once('clientReady', async () => {
    console.log(`✅ Logged in as ${client.user.tag}!`);
    
    client.user.setActivity(CUSTOM_STATUS, { type: ActivityType.Playing });
    console.log(`⭐ Status set to: ${CUSTOM_STATUS}`);
});

client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(`Error executing command /${interaction.commandName}:`, error);
            const errorMessage = 'An error occurred while executing this command!';
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true });
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
        }
    }
});

client.login(process.env.DISCORD_TOKEN);