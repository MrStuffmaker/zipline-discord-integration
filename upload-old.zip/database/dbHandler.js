import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DATA_DIR = join(__dirname, '..', 'data', 'users');

// Ensure data directory exists
if (!existsSync(DATA_DIR)) {
    mkdirSync(DATA_DIR, { recursive: true });
}

/**
 * Get user auth token
 */
export const getUserToken = (userId) => {
    const filePath = join(DATA_DIR, `${userId}.json`);
    if (!existsSync(filePath)) return null;
    
    try {
        const data = JSON.parse(readFileSync(filePath, 'utf-8'));
        return data.token || null;
    } catch (error) {
        console.error(`Error reading user token for ${userId}:`, error);
        return null;
    }
};

/**
 * Save user auth token
 */
export const saveUserToken = (userId, token) => {
    const filePath = join(DATA_DIR, `${userId}.json`);
    
    try {
        const userData = existsSync(filePath) ? JSON.parse(readFileSync(filePath, 'utf-8')) : {};
        userData.token = token;
        userData.savedAt = new Date().toISOString();
        
        writeFileSync(filePath, JSON.stringify(userData, null, 2));
        return true;
    } catch (error) {
        console.error(`Error saving user token for ${userId}:`, error);
        return false;
    }
};

/**
 * Get user upload history
 */
export const getUserHistory = (userId) => {
    const filePath = join(DATA_DIR, `${userId}.json`);
    if (!existsSync(filePath)) return [];
    
    try {
        const data = JSON.parse(readFileSync(filePath, 'utf-8'));
        return data.history || [];
    } catch (error) {
        console.error(`Error reading history for ${userId}:`, error);
        return [];
    }
};

/**
 * Add upload to history
 */
export const addToHistory = (userId, uploadData) => {
    const filePath = join(DATA_DIR, `${userId}.json`);
    
    try {
        const userData = existsSync(filePath) ? JSON.parse(readFileSync(filePath, 'utf-8')) : {};
        if (!userData.history) userData.history = [];
        
        userData.history.push({
            timestamp: new Date().toISOString(),
            ...uploadData
        });
        
        writeFileSync(filePath, JSON.stringify(userData, null, 2));
        return true;
    } catch (error) {
        console.error(`Error adding to history for ${userId}:`, error);
        return false;
    }
};

/**
 * Clear user history
 */
export const clearHistory = (userId) => {
    const filePath = join(DATA_DIR, `${userId}.json`);
    
    try {
        const userData = existsSync(filePath) ? JSON.parse(readFileSync(filePath, 'utf-8')) : {};
        userData.history = [];
        
        writeFileSync(filePath, JSON.stringify(userData, null, 2));
        return true;
    } catch (error) {
        console.error(`Error clearing history for ${userId}:`, error);
        return false;
    }
};

/**
 * Delete history (alias for clearHistory)
 */
export const deleteHistory = (userId) => {
    return clearHistory(userId);
};