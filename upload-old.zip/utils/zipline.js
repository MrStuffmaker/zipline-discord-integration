import axios from 'axios';
import fs from 'fs';
import path from 'path';

const ZIPLINE_API_URL = process.env.ZIPLINE_API_URL;

export const uploadFileToZipline = async (token, file) => {
    try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await axios.post(`${ZIPLINE_API_URL}/upload`, formData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                ...formData.getHeaders(),
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error uploading file to Zipline:', error);
        throw new Error('Failed to upload file to Zipline.');
    }
};

export const fetchUserFiles = async (token) => {
    try {
        const response = await axios.get(`${ZIPLINE_API_URL}/user/files`, {
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });

        return response.data;
    } catch (error) {
        console.error('Error fetching user files from Zipline:', error);
        throw new Error('Failed to fetch user files from Zipline.');
    }
};

export const saveUserData = (userId, data) => {
    const userFilePath = path.join(__dirname, '../../data/users', `${userId}.json`);
    fs.writeFileSync(userFilePath, JSON.stringify(data, null, 2));
};

export const loadUserData = (userId) => {
    const userFilePath = path.join(__dirname, '../../data/users', `${userId}.json`);
    if (fs.existsSync(userFilePath)) {
        const data = fs.readFileSync(userFilePath);
        return JSON.parse(data);
    }
    return null;
};