import fs from 'fs';
import path from 'path';
import axios from 'axios';

const usersDir = path.join(__dirname, '../../data/users');

/**
 * Validate Zipline token and get user data
 */
export const validateToken = async (token, ziplineUrl) => {
    try {
        const response = await axios.get(`${ziplineUrl}/api/user`, {
            headers: {
                'Authorization': token
            }
        });
        return response.data;
    } catch (error) {
        console.error('Token validation failed:', error.message);
        return null;
    }
};

/**
 * Get user data from Zipline
 */
export const getUserData = async (token, ziplineUrl) => {
    try {
        const response = await axios.get(`${ziplineUrl}/api/user`, {
            headers: {
                'Authorization': token
            }
        });
        return response.data;
    } catch (error) {
        console.error('Failed to get user data:', error.message);
        return null;
    }
};

export const getUserDataFilePath = (userId) => {
    return path.join(usersDir, `${userId}.json`);
};

export const saveUserData = (userId, data) => {
    const filePath = getUserDataFilePath(userId);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

export const loadUserData = (userId) => {
    const filePath = getUserDataFilePath(userId);
    if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath);
        return JSON.parse(data);
    }
    return null;
};